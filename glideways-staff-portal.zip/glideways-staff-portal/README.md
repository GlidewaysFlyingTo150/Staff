# Glideways Staff Portal

A staff-only site with a login screen, a Documents tab, an Updates tab, and a Contact tab.

Login uses **Firebase Authentication** (email/password). Firebase is free for this
scale of use, needs no server or bot, and works from a static site hosted on
GitHub Pages. You add staff accounts by hand in the Firebase console — there's
no self-signup.

## 1. Create a Firebase project

1. Go to https://console.firebase.google.com and click **Add project**.
2. Give it any name (e.g. "glideways-staff-portal"). You can disable Google
   Analytics for this project — it's not needed.
3. Once created, click the **web** icon (`</>`) to register a web app. Give it
   a nickname — you don't need Firebase Hosting.
4. Firebase will show you a `firebaseConfig` object with keys like `apiKey`,
   `authDomain`, etc. Copy those values into `js/firebase-config.js` in this
   project, replacing the placeholder strings.

## 2. Turn on email/password sign-in

1. In the Firebase console, go to **Build → Authentication**.
2. Click **Get started**, then open the **Sign-in method** tab.
3. Enable **Email/Password**.

## 3. Add staff accounts

1. In **Authentication → Users**, click **Add user**.
2. Enter each staff member's email and a temporary password.
3. Share that email/password with the staff member. They can sign in right
   away; there's no separate "username" — the email address is the login.
4. To remove someone's access later, delete their user from this same list.

## 4. Restrict which domains can use this login

By default Firebase only allows sign-in from domains you've authorized.

1. Still in **Authentication → Settings → Authorized domains**, add your
   GitHub Pages domain, e.g. `yourusername.github.io`.
2. `localhost` is included by default, which is useful for testing before you
   deploy.

## 5. Deploy with GitHub Pages

1. Push this folder to a GitHub repository.
2. In the repo, go to **Settings → Pages**.
3. Under **Source**, choose the branch (usually `main`) and the root folder,
   then save.
4. GitHub will give you a URL like `https://yourusername.github.io/repo-name/`.
   That's your staff portal.

## Project structure

```
index.html          Login page
portal.html          Documents / Updates / Contact tabs (after sign-in)
css/style.css        Shared brand styles and tokens
css/login.css        Login page styles
css/portal.css       Portal shell, sidebar, and tab styles
js/firebase-config.js  Your Firebase project keys (fill this in)
js/auth.js           Login form logic
js/portal.js          Auth guard, tab switching, sign out, clock
```

## Editing content

- **Documents tab** (`portal.html`, `#panel-documents`): each `.doc-card` is a
  link — swap the placeholder `href="#"` for a real link (Google Drive,
  Notion, a hosted PDF, etc.) and edit the title/description.
- **Updates tab** (`#panel-updates`): each `.update-item` is one announcement.
  Copy the block to add more, newest at the top.
- **Contact tab** (`#panel-contact`): each `.contact-card` is one person or
  role — edit the name, role, and links.

## A note on security

This setup is genuine username/password authentication — not just a
cosmetic gate. Firebase verifies credentials server-side, and the config
values in `firebase-config.js` are meant to be public (they identify your
project, not secret keys). Real access control comes from which users you've
created in the Firebase console and from the authorized-domains list, so
keep both of those tidy as staff join or leave.
